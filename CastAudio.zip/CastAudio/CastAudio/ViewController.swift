//
//  ViewController.swift
//  CastAudio
//
//  Created by Muvi on 22/08/17.
//  Copyright © 2017 Suraj-ios. All rights reserved.
//

import UIKit

class ViewController: UIViewController,GCKSessionManagerListener, GCKDeviceScannerListener,GCKDeviceManagerDelegate {

    var appD:AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    @IBOutlet weak var miniCastingView: UIView!
    
    //google cast
    var timer:Timer!
    var miniMediaViewController:GCKUIMiniMediaControlsViewController!
    var remoteClient:GCKRemoteMediaClient!
    var mediaData:String!
    var googleCastButto:GCKUICastButton!
    private var deviceScanner: GCKDeviceScanner
    var mediaInformation: GCKMediaInformation?
    var castToSwitchButton:UIButton!
    
    private lazy var kReceiverAppID:String = {
        return "9C631550"
    }()
    
    required init(coder aDecoder: NSCoder) {
        let filterCriteria = GCKFilterCriteria(forAvailableApplicationWithID:
            kGCKMediaDefaultReceiverApplicationID)
        deviceScanner = GCKDeviceScanner(filterCriteria:filterCriteria)
        super.init(coder: aDecoder)!
    }
    //end
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //cast miniView hide/unhide here
        self.miniCastingView.isHidden = true
        
        //cast functionality use here now
        googleCastButto = GCKUICastButton(frame: CGRect(x: 0, y: 0, width: 24, height: 24))
        googleCastButto.tintColor = UIColor.red
        GCKCastContext.sharedInstance().sessionManager.add(self)
        var barBu:UIBarButtonItem = UIBarButtonItem(customView: googleCastButto)
        
        navigationItem.leftItemsSupplementBackButton = true
        var spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace
            , target: nil, action: nil)
        navigationItem.setRightBarButtonItems([barBu,spaceButton], animated: false)
        //end now
        
    }

    //cast delegate func 
    func sessionManager(_ sessionManager: GCKSessionManager, didEnd session: GCKSession, withError error: Error?) {
        
       print("session end now")
       self.miniCastingView.isHidden = true
    }
    
    func sessionManager(_ sessionManager: GCKSessionManager, didStart session: GCKCastSession) {
        
        print("Session starts")
        
        self.appD.isReadyToCast = true
        
        self.remoteClient = GCKCastContext.sharedInstance().sessionManager.currentCastSession?.remoteMediaClient
        
    }
    var audioUrl:String = "http://videos.revision3.com/diggnation/0093/diggnation--0093--2007-04-11--high.mp3"
    
    var posterUrl:String = "https://i.ndtvimg.com/i/2017-06/baadshaho_650x400_81497418755.jpg"
    var audioName:String = "Baadshaho"
    var Audiostory:String = "Baadshaho is coming soon"
    
    @IBAction func playButton(_ sender: Any)
    {
        self.miniCastingView.isHidden = true
        self.streamToDevice(self.audioUrl)
    }
    
    func streamToDevice(_ urlss:String) {
        
        print("Urls:- \(urlss)")
        let metadata = GCKMediaMetadata()
        
        metadata.addImage(GCKImage(url: URL(string:self.posterUrl)!, width: 280, height: 160))
        metadata.setString(self.audioName, forKey: kGCKMetadataKeyTitle)
        metadata.setString(self.Audiostory, forKey: kGCKMetadataKeySubtitle)
        
        self.mediaInformation = GCKMediaInformation(contentID: urlss, streamType: GCKMediaStreamType.buffered, contentType: "audio/mp3", metadata: metadata, streamDuration: TimeInterval(FP_INFINITE), mediaTracks: nil, textTrackStyle: nil, customData: nil)
        
        self.remoteClient.loadMedia(mediaInformation!, autoplay: true)
        
        var context : GCKCastContext = GCKCastContext.sharedInstance()
        miniMediaViewController = context.createMiniMediaControlsViewController()
        self.addChildViewController(miniMediaViewController)
        self.miniCastingView.isHidden = false
        self.miniMediaViewController.view.frame = self.miniCastingView.bounds
        self.miniCastingView.addSubview(self.miniMediaViewController.view)
        self.miniMediaViewController.didMove(toParentViewController: self)
        
        var expand = context.defaultExpandedMediaControlsViewController
        expand.editButtonItem.title = "Done"
        
        expand.setButtonType(GCKUIMediaButtonType.none, at: 0)
        expand.setButtonType(GCKUIMediaButtonType.none, at: 1)
        expand.setButtonType(GCKUIMediaButtonType.none, at: 2)
        
        print("enter into remote part")
        
    }
    
    override func remoteControlReceived(with event: UIEvent?) {
        let rc = event!.subtype
        
        print("received remote control \(rc.rawValue)")
        
        switch rc {
        case .remoteControlTogglePlayPause: break
        case .remoteControlPlay: break
        case .remoteControlPause: break
            
        case .remoteControlNextTrack: break
        default:break
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

