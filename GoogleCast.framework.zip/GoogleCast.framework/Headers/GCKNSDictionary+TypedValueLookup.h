// Copyright 2012 Google Inc.

#import <GoogleCast/NSDictionary+GCKAdditions.h>
